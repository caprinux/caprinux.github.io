#include <stdio.h>
#include <unistd.h>
int main(int argc, char** argv){
	setvbuf(stdout, NULL, _IONBF, 0);
	vuln();
}

int vuln(void){
	char buf[128];
	gets(buf);
	return 0;
}

int win(long a, long b, long c){
	if(!(a == 0xdeadbeef)) return 1;
	if(!(b == 0xcafebabecafebabe)) return 1;
	if(!(c == 0xd00df00dd00df00d)) return 1;

	char buf[64];
	FILE *f = fopen("flag.txt","r");
	if (f == NULL) {
	printf("Run this on the server.\n");
	exit(0);
	}

	fgets(buf,64,f);
	printf(buf);

	return 0;	
}