#include <stdio.h>
#include <unistd.h>
int main(int argc, char** argv){
	vuln();
}

int vuln(void){
	char buf[128];
	read(0, buf, 300);
	return 0;
}