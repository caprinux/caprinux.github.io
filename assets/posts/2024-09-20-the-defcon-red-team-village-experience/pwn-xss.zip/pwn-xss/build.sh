#!/usr/bin/env bash

docker rm -f xss
docker build -t xss . && docker run -d --restart unless-stopped -p 1337:1337 --name xss xss
