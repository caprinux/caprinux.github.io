#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <pthread.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "util.h"
#include "http.h"
#include "server.h"

#define MAX_PATH_LEN 0x800
#define MAX_CONTENT_LENGTH 0x100
#define MAX_COOKIE_LEN 0x100
#define MAX_HOST_LEN 0x50
#define MAX_USERAGENT_LEN 0x80
#define MAX_RESP_LINE_LEN 0X40


#define PRODUCTION
#ifndef PRODUCTION
#define FLAG_PATH "./flag"
#define TEMPLATE_PATH "./templates/index.templ"
#else
#define FLAG_PATH "/home/ctf/flag"
#define TEMPLATE_PATH "/home/ctf/templates/index.templ"
#endif

int reqfd = -1;
int PORT = 1337;

pthread_mutex_t mutex;
pthread_mutex_t bot_mutex;
pthread_cond_t cond_var;
pthread_cond_t bot_cond_var;

char *Feedback;
char *admin_cookie;

void init() {
    setvbuf(stdin, 0, _IONBF, 0);
    setvbuf(stdout, 0, _IONBF, 0);
    setvbuf(stderr, 0, _IONBF, 0);
}

enum Method get_request_method(char* line) {
    char* ptr = line;
    while (*ptr != ' ') ptr++;
    *ptr = '\0';

    if (!strcmp(line, "GET")) {
        return GET;
    } else if (!strcmp(line, "POST")) {
        return POST;
    } else {
        info("Method not implemented");
        exit(-1);
    }
}

char* get_request_path(char* line) {
    char* ptr = line;
    char* path;
    size_t path_len = 0;

    while (*ptr != '\0') ptr++;
    ptr++;

    while (*ptr != ' ') {
        path_len++;
        ptr++;
    }

    if (path_len > MAX_PATH_LEN) {
        info("Invalid path length");
        exit(-1);
    }

    *ptr = '\0';
    path = (char*)malloc(path_len);
    strcpy(path, ptr-path_len);
    return path;
}

struct Request *parse_request(int fd) {
    struct Request request, *request_p;
    char *line = recvline(fd);
    char *ptr = 0;
    char *buffer = 0;

    memset((char*)&request, 0, sizeof(struct Request));

    // parse status line
    request.method = get_request_method(line);
    request.path = get_request_path(line);

    free(line);
    line = 0;

    while (true) {
        line = recvline(fd);
        if (*line == 0x0d) {
            // info("found request end");
            break;
        }

        // parse headers
        if (!strncmp("Host: ", line, 6)) {
            ptr = line + 6;
            if (strlen(ptr) <= MAX_HOST_LEN) {
                buffer = (char*)malloc(strlen(ptr));
                strcpy(buffer, ptr);
                request.host = buffer;
                // info("Host: %s", request.host);
            }
            
        } else if (!strncmp("Cookie: ", line, 8)) {
            ptr = line + 8;
            if (strlen(ptr) <= MAX_COOKIE_LEN) {
                buffer = (char*)malloc(strlen(ptr));
                strcpy(buffer, ptr);
                request.cookie = buffer;
                // info("Cookie: %s", request.cookie);
            }
            
        } else if (!strncmp("User-Agent: ", line, 12)) {
            ptr = line + 12;
            if (strlen(ptr) <= MAX_USERAGENT_LEN) {
                buffer = (char*)malloc(strlen(ptr));
                strcpy(buffer, ptr);
                request.cookie = buffer;
                // info("User-Agent: %s", request.cookie);
            }
            
        } else if (!strncmp("Content-Length: ", line, 16)) {
            ptr = line + 16;
            sscanf(ptr, "%zu", &request.content_length);
            // info("Content-Length: %d", request.content_length);

            if (request.content_length > MAX_CONTENT_LENGTH) {
                info("Invalid Content length");
                exit(-1);
            }

            request_p = (struct Request*)malloc(sizeof(struct Request) + request.content_length);
        } else if (!strncmp("Upgrade-Insecure-Requests: ", line, 27)) {
            ptr = line + 27;
            sscanf(ptr, "%zu", &request.upgrade_insecure_requests);
            // info("Upgrade-insecure-requests: %d", request.upgrade_insecure_requests);
        } else {
            // info("Unrecognized request header: %s", line);
        }

        // info("Client said: %s", line);
        free(line);
        line = 0;
        buffer = 0;
    }

    free(line);
    line = 0;

    if (!request.content_length) {
        request_p = (struct Request*)malloc(sizeof(struct Request));
    }

    memcpy((char*)request_p, (char*)&request, sizeof(struct Request));

    if (request_p->content_length) {
        read(reqfd, (char*)request_p->body, request.content_length);
    }

    return request_p;
}

void respond(struct Request* request) {
    // info("=========================== request body ============================");
    // info("Host: %s", request->host);
    // info("Path: %s", request->path);
    // info("Method: %d", request->method);
    // info("User-Agent: %s", request->user_agent);
    // info("Upgrade-Insecure-Requests: %d", request->upgrade_insecure_requests);
    // info("Content-Length: %zu", request->content_length);
    // if (request->content_length) {
    //     info("Body: %s", request->body);
    // }

    struct Response* resp = handle_request(request, request->path);
    char resp_line[MAX_RESP_LINE_LEN] = {0};
    
    switch (resp->status) {
        case Continue: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Continue");
            break;
        }
        case Ok: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Ok");
            break;
        }
        case MovedPermanently: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Moved Permanently");
            break;
        }
        case Bad: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Bad");
            break;
        }
        case Forbidden: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Forbidden");
            break;
        }
        case NotFound: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Not Found");
            break;
        }
        case ServerError: {
            sprintf(&resp_line, "HTTP/1.1 %d %s\r\n", resp->status, "Internal Server Error");
            break;
        }
    }


    write(reqfd, resp_line, strlen(resp_line));
    write(reqfd, resp->content_type, strlen(resp->content_type));
    if (resp->headers) write(reqfd, resp->headers, strlen(resp->headers));

    write(reqfd, "\r\n", 2);
    if (resp->resp_body) write(reqfd, resp->resp_body, strlen(resp->resp_body));

    free_all(request, resp);
}

struct Response* handle_request(struct Request* req, char* path) {
    struct Response* resp = (struct Response*)malloc(sizeof(struct Response));

    memset((char*)resp, 0, sizeof(struct Response));
    resp->content_type = (char*)malloc(39);
    memcpy(resp->content_type, "Content-Type: text/html;charset=utf-8\r\n", 39);

    switch (req->method) {
        case GET: {
            if (!strncmp(req->path, "/index", 6)) {
                int fd = open(TEMPLATE_PATH, O_RDONLY);
                if (fd < 0) {
                    perror("open");
                    exit(-1);
                }

                struct stat st;
                stat(TEMPLATE_PATH, &st);

                resp->status = Ok;
                resp->resp_body = (char*)malloc(st.st_size);
                // resp->content_type = (char*)malloc(39);

                read(fd, resp->resp_body, st.st_size);
            } else if (!strncmp(req->path, "/feedback?fb=", 13)) {
                char *feedback = req->path + 13;
                resp->resp_body = (char*)malloc(15+strlen(feedback));
                sprintf(resp->resp_body, "Your Feedback: %s\0", feedback);

                resp->status = Ok;
                // resp->content_type = (char*)malloc(39);
            } else if (!strncmp(req->path, "/\0", 2)) {
                resp->status = MovedPermanently;
                resp->headers = (char*)malloc(18);

                memcpy(resp->headers, "Location: /index\r\n", 18);
            }  else if (!strncmp(req->path, "/report", 7)) {
                if (!strncmp(req->path, "/report?fb=", 11)) {
                    char *feedback = req->path + 11;
                    Feedback = (char*)malloc(strlen(feedback));

                    strcpy(Feedback, feedback);

                    for (int i = 0; i < strlen(feedback); i++) {
                        if (Feedback[i] == '\'') {
                            Feedback[i] = '"';
                        }
                    }

                    pthread_cond_signal(&bot_cond_var);

                    resp->status = Ok;
                    resp->resp_body = (char*)malloc(46);
                    memcpy(resp->resp_body, "</h1>Admin will check your feedback soon</h1>\0", 46);
                } else {
                    resp->status = Bad;
                    resp->resp_body = (char*)malloc(24);
                    memcpy(resp->resp_body, "<h1>Feedback not found</h1>\0", 24);
                }
            } else {
                resp->status = NotFound;
                resp->resp_body = (char*)malloc(24);
                memcpy(resp->resp_body, "<h1>Page Not Found</h1>\0", 24);
            }
            break;
        }
        case POST: {
            if (!strncmp(req->path, "/comment", 8)) {
                if (!strncmp(req->body, "comment=", 8)) {
                    char *comment = req->body+8;

                    resp->status = Ok;
                    resp->resp_body = (char*)malloc(20+strlen(comment));
                    sprintf(resp->resp_body, "<p>commoner: %s</p>\0", comment);

                    break;
                };

                resp->status = Bad;
                resp->resp_body = (char*)malloc(44);
                memcpy(resp->resp_body, "<h1>Post data does not contain comment</h1>\0", 44);
                break;
            }
        }
        default: {
                resp->status = NotFound;
                resp->resp_body = (char*)malloc(32);
                memcpy(resp->resp_body, "<h1>Method not implemented</h1>\0", 32);
            }
    };

    return resp;
}

void bot_visit(){
    char command[0x200];

    while (true) {
        pthread_cond_wait(&bot_cond_var, &bot_mutex);
        
        sleep(2);
        sprintf(&command, "curl 'http://localhost:1337/feedback?fb=%s' -H 'User-Agent: The king of kings' -H 'Accept:' -H 'Host:' -H 'Cookie: auth=%s'", Feedback, admin_cookie);
        // info(command);
        free(Feedback);
        Feedback = 0;

        // ?!?!?!?!?!?!?!?!?!?! omg no wayyyyyyy, command injection?!?!??!?
        system(command);
    }
}

void setup() {
    int fd = 0;
    struct stat st;
    uint64_t buffer = 0;

    admin_cookie = malloc(32);

    stat(FLAG_PATH, &st);
    if (st.st_size <= 0) {
        exit(-1);
    }

    fd = open(FLAG_PATH, O_RDONLY);
    if (fd < 0) {perror("open"); exit(-1);}

    read(fd, admin_cookie, st.st_size);
    close(fd);
    return;
}

int main() {    
    pthread_t t1, t2;

    init();
    setup();

    if (pthread_mutex_init(&mutex, NULL) != 0) {
        perror("Mutex initialization");
        exit(-1);
    }

    if (pthread_cond_init(&cond_var, NULL) != 0) {
        perror("pthread_cond_init");
        exit(-1);
    }


    if (pthread_mutex_init(&bot_mutex, NULL) != 0) {
        perror("Mutex initialization");
        exit(-1);
    }

    if (pthread_cond_init(&bot_cond_var, NULL) != 0) {
        perror("pthread_cond_init");
        exit(-1);
    }

    if (pthread_create(&t1, NULL, (void*)start_server, PORT) < 0) {
        perror("pthread_create");
        exit(-1);
    }

    if (pthread_create(&t2, NULL, (void*)bot_visit, NULL) < 0) {
        perror("pthread_create");
        exit(-1);
    }

    while (true) {
        pthread_cond_wait(&cond_var, &mutex);

        respond(parse_request(reqfd));

        pthread_cond_signal(&cond_var);
    }

    if (pthread_join(t1, NULL) < 0) {
        perror("pthread_join");
        exit(-1);
    }

    pthread_mutex_destroy(&mutex);

    return 0;
}