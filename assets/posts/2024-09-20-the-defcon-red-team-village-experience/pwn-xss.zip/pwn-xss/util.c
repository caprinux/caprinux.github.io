#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <stdarg.h>


#include "util.h"
#include "http.h"

void info(const char* format, ...) {
    if (!format) {
        return;
    }
    
    fprintf(stdout, "%s", "[+] ");
    va_list args;
    va_start(args, format);
    vfprintf(stdout, format, args);
    va_end(args);
    fprintf(stdout, "%s", "\n");
}

char* recvline(int fd) {
    char c = 0;
    char *buffer = 0;
    size_t read_size = 0;
    size_t buffer_size = 24;

    buffer = (char*)malloc(buffer_size);

    while (read(fd, &c, 1) == 1) {
        if ((c == '\0' || c == '\n') && read_size == 0) return NULL;

        if (read_size == buffer_size) {
            buffer_size = buffer_size * 2;
            buffer = realloc(buffer, buffer_size);
        }

        if (c == '\n') {
            // reached EOL
            buffer[read_size] = '\0';
            return buffer;
        }

        buffer[read_size++] = c;
    }

    // reached EOF
    return buffer;
}

void free_all(struct Request *req, struct Response *resp){
    // request
    if (req->path) free(req->path);
    if (req->host) free(req->host);
    if (req->user_agent) free(req->user_agent);
    if (req->cookie) free(req->cookie);
    free(req);

    // response
    if (resp->headers) free(resp->headers);
    if (resp->resp_body) free(resp->resp_body);
    if (resp->content_type) free(resp->content_type);
    free(resp);
}