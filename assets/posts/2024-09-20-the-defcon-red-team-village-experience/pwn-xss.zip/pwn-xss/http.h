#ifndef INCLUDE_HTTP
#define INCLUDE_HTTP

enum Method {
    GET,
    HEAD,
    POST,
    PUT,
    DELETE,
    CONNECT,
    OPTIONS,
    TRACE,
    PATCH
};

enum StatusCode {
    Continue = 100,
    Ok = 200,
    MovedPermanently = 301,
    Bad = 400,
    Forbidden = 403,
    NotFound = 404,
    ServerError = 500
};

struct Request {
    enum Method method;
    char* path;
    char* host;
    char* user_agent;
    int upgrade_insecure_requests;
    size_t content_length;
    char* cookie;
    char body[];
} __attribute__((packed));

struct Response {
    enum StatusCode status;
    char *content_type;
    char *headers;
    char *resp_body;
};

#endif

extern int sockfd;

struct Response* handle_request(struct Request* req, char *path);