#ifndef INCLUDE_SERVER
#define INCLUDE_SERVER


extern int reqfd;
extern pthread_mutex_t mutex;
extern pthread_cond_t cond_var;

#endif

void start_server(uint32_t port);