#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <assert.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "server.h"
#include "util.h"

int sockfd = 0;

void start_server(uint32_t port) {
    // create a socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {perror("socket"); exit(-1);}

    int reuseaddr = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &reuseaddr, sizeof(reuseaddr)) < 0) {
        perror("Setsockopt");
        close(sockfd);
        exit(-1);
    }

    // bind it to ip and port
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    socklen_t len = sizeof(struct sockaddr_in);
    if (bind(sockfd, (struct sockaddr*)&addr, len) != 0) {
        perror("bind");
        exit(-1);
    }

    // listen for connections
    if (listen(sockfd, 5) != 0 ) {
        perror("listen");
        exit(-1);
    }

    info("HTTP server running on port: %d", port);

    // accept connections, and main thread
    while (true) {
        struct sockaddr client_addr;
        len = sizeof(struct sockaddr);
        reqfd = accept(sockfd, (struct sockaddr*)&client_addr, &len);
        if (reqfd < 0) { 
            perror("accept");
            exit(-1);
        }

        pthread_cond_signal(&cond_var);
        pthread_cond_wait(&cond_var, &mutex);

        close(reqfd);
    }
}

