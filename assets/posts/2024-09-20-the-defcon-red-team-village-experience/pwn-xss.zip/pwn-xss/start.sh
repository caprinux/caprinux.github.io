#!/usr/bin/env bash

while true
do
    /home/ctf/xss
done