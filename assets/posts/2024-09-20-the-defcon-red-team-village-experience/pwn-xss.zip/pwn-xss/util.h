char* recvline(int fd);
void info(const char* format, ...);